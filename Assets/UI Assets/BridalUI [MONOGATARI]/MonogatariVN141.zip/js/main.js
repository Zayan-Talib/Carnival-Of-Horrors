/**
 * ==============================
 * Your Javascript Code Goes Here
 * ==============================
 **/

/*function hideCentered () {
    $_("[data-ui='centered']").fadeOut(400).delay(800).remove();
    $_("[data-ui='text']").show();
};

$_("body").on("click", "[data-do]", function () {
    hideCentered();
    shutUp();
    
    
    if ($_(this).data("do") != "null" && $_(this).data("do") != "") {
        try {
            $_animationClick("[data-ui='choices']", bounce);
            
            $_("[data-ui='choices']").hide();
            
            $_("[data-ui='choices']").html("");
            analyseStatement($_(this).data("do"), false);
        } catch (e) {
            console.error("An error ocurred while trying to execute the choice's action.\n" + e);
        }
    }
});*/