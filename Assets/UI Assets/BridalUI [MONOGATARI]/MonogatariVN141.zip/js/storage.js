"use strict";
// Persistent Storage Variable

let storage = {
	player: {
		name: ""
	}
};